from random import *
random_number = randint(1, 6)
guess = int(input("Guess a number between 1 and 6: "))
if guess == random_number:
  print("You guessed it!")
else:
  print ("Try again.")